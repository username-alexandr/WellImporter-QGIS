# -*- coding: utf-8 -*-

from dataclasses import dataclass

from qgis.core import (
    QgsProject,
    QgsFeature,
    QgsCoordinateTransform,
    QgsWkbTypes,
    QgsMapLayerType,
    NULL
)

from .geometry import GeometryBuilder
from .importer import ClipboardImporter
from .logger import ImportLogger
from .progress import Progress
from .validator import Validator


@dataclass
class ImportResult:
    added_points: int = 0
    added_circles: int = 0
    skipped_duplicates: int = 0
    errors: int = 0
    log_file: str = ""


class ImportController:
    """Coordinates clipboard parsing, geometry generation and writing to QGIS layers."""

    POINT_NUMBER_FIELD = "Номер скважины"
    POINT_YEAR_FIELD = "Год"

    def __init__(self, iface):
        self.iface = iface
        self.project = QgsProject.instance()
        self.importer = ClipboardImporter()
        self.geometry = GeometryBuilder()
        self.logger = ImportLogger()

    def layer_by_id(self, layer_id):
        layer = self.project.mapLayer(layer_id)
        if layer is None:
            raise Exception("Выбранный слой не найден в проекте.")
        return layer

    def execute(self, point_layer_id, polygon_layer_id, year, area):
        point_layer = self.layer_by_id(point_layer_id)
        polygon_layer = self.layer_by_id(polygon_layer_id)

        self._validate_layers(point_layer, polygon_layer)
        self._validate_fields(point_layer)

        records = self.importer.parse()

        if not records:
            raise Exception("В буфере обмена не найдено строк для импорта.")

        result = ImportResult(log_file=self.logger.file_path)

        validator = Validator(point_layer, self.POINT_NUMBER_FIELD)
        progress = Progress(self.iface, len(records), "Импорт скважин...")

        point_was_editable = point_layer.isEditable()
        polygon_was_editable = polygon_layer.isEditable()

        try:
            if not point_was_editable:
                if not point_layer.startEditing():
                    raise Exception(f"Не удалось включить редактирование слоя: {point_layer.name()}")

            if not polygon_was_editable:
                if not polygon_layer.startEditing():
                    raise Exception(f"Не удалось включить редактирование слоя: {polygon_layer.name()}")

            for i, record in enumerate(records, start=1):
                progress.set_value(i)

                if progress.was_canceled():
                    self.logger.write("Импорт отменён пользователем.")
                    break

                if validator.exists(record.number):
                    result.skipped_duplicates += 1
                    self.logger.write(f"Пропущен дубль: скважина №{record.number}")
                    continue

                try:
                    point_feature = self._make_point_feature(point_layer, record, year)
                    ok_point = point_layer.addFeature(point_feature)

                    circle_feature = self._make_circle_feature(
                        polygon_layer=polygon_layer,
                        source_record=record,
                        area=area,
                        number=record.number,
                        year=year
                    )
                    ok_circle = polygon_layer.addFeature(circle_feature)

                    if not ok_point or not ok_circle:
                        raise Exception("QGIS не добавил один из объектов в слой.")

                    result.added_points += 1
                    result.added_circles += 1
                    self.logger.write(f"Добавлена скважина №{record.number}, год {year}")

                except Exception as exc:
                    result.errors += 1
                    self.logger.write(f"Ошибка строки {i}, скважина №{record.number}: {exc}")

            if not point_was_editable:
                if not point_layer.commitChanges():
                    raise Exception(f"Не удалось сохранить изменения слоя: {point_layer.name()}")

            if not polygon_was_editable:
                if not polygon_layer.commitChanges():
                    raise Exception(f"Не удалось сохранить изменения слоя: {polygon_layer.name()}")

            point_layer.triggerRepaint()
            polygon_layer.triggerRepaint()
            self.iface.mapCanvas().refresh()

            self.logger.write(
                f"Итог: точек {result.added_points}, кругов {result.added_circles}, "
                f"дублей {result.skipped_duplicates}, ошибок {result.errors}"
            )

        except Exception:
            if not point_was_editable and point_layer.isEditable():
                point_layer.rollBack()
            if not polygon_was_editable and polygon_layer.isEditable():
                polygon_layer.rollBack()
            raise

        finally:
            progress.close()

        return result

    def _validate_layers(self, point_layer, polygon_layer):
        if point_layer.type() != QgsMapLayerType.VectorLayer:
            raise Exception("Слой скважин должен быть векторным.")

        if polygon_layer.type() != QgsMapLayerType.VectorLayer:
            raise Exception("Слой кругов должен быть векторным.")

        point_geom = QgsWkbTypes.geometryType(point_layer.wkbType())
        polygon_geom = QgsWkbTypes.geometryType(polygon_layer.wkbType())

        if point_geom != QgsWkbTypes.PointGeometry:
            raise Exception("Слой «Скважины солевая съёмка» должен быть точечным.")

        if polygon_geom != QgsWkbTypes.PolygonGeometry:
            raise Exception("Слой «Площадные круги» должен быть полигональным.")

        if point_layer.readOnly():
            raise Exception(f"Слой точек доступен только для чтения: {point_layer.name()}")

        if polygon_layer.readOnly():
            raise Exception(f"Слой кругов доступен только для чтения: {polygon_layer.name()}")

    def _validate_fields(self, point_layer):
        names = point_layer.fields().names()
        missing = []

        if self.POINT_NUMBER_FIELD not in names:
            missing.append(self.POINT_NUMBER_FIELD)

        if self.POINT_YEAR_FIELD not in names:
            missing.append(self.POINT_YEAR_FIELD)

        if missing:
            raise Exception(
                "В слое скважин отсутствуют обязательные поля:\n"
                + "\n".join(missing)
            )

    def _make_point_feature(self, point_layer, record, year):
        feature = QgsFeature(point_layer.fields())

        point_geometry_4326 = self.geometry.create_point(record.x, record.y)
        geometry = self.geometry.transform_geometry_to_layer(point_geometry_4326, point_layer)
        feature.setGeometry(geometry)

        feature[self.POINT_NUMBER_FIELD] = record.number
        feature[self.POINT_YEAR_FIELD] = year

        return feature

    def _make_circle_feature(self, polygon_layer, source_record, area, number, year):
        feature = QgsFeature(polygon_layer.fields())

        circle_4326 = self.geometry.create_circle(source_record.x, source_record.y, area)
        geometry = self.geometry.transform_geometry_to_layer(circle_4326, polygon_layer)
        feature.setGeometry(geometry)

        # Записываем атрибуты в слой кругов только если такие поля там есть.
        field_names = feature.fields().names()
        if self.POINT_NUMBER_FIELD in field_names:
            feature[self.POINT_NUMBER_FIELD] = number
        if self.POINT_YEAR_FIELD in field_names:
            feature[self.POINT_YEAR_FIELD] = year

        return feature
