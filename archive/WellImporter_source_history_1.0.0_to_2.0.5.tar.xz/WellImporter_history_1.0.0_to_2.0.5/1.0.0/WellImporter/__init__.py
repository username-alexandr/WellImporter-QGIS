# -*- coding: utf-8 -*-

def classFactory(iface):
    """QGIS plugin entry point."""
    from .well_importer import WellImporter
    return WellImporter(iface)
