# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QProgressDialog


class Progress:
    """Progress dialog wrapper."""

    def __init__(self, iface, maximum, title="Выполнение..."):
        self.dialog = QProgressDialog(
            title,
            "Отмена",
            0,
            max(1, int(maximum)),
            iface.mainWindow()
        )
        self.dialog.setWindowModality(Qt.WindowModal)
        self.dialog.setMinimumDuration(0)
        self.dialog.setAutoClose(False)
        self.dialog.setAutoReset(False)

    def set_value(self, value):
        self.dialog.setValue(value)

    def was_canceled(self):
        return self.dialog.wasCanceled()

    def close(self):
        self.dialog.close()
