# -*- coding: utf-8 -*-

import math

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGeometry,
    QgsPointXY,
    QgsProject
)


class GeometryBuilder:
    """Builds point and circle geometry from EPSG:4326 input coordinates."""

    SOURCE_CRS = QgsCoordinateReferenceSystem("EPSG:4326")

    def __init__(self):
        self.project = QgsProject.instance()

    def radius_from_area(self, area):
        if area <= 0:
            raise Exception("Площадь круга должна быть больше нуля.")
        return math.sqrt(float(area) / math.pi)

    def utm_epsg(self, lon, lat):
        zone = int((lon + 180.0) / 6.0) + 1
        zone = max(1, min(60, zone))

        if lat >= 0:
            return 32600 + zone

        return 32700 + zone

    def create_point(self, lon, lat):
        lon, lat = self.normalize_lon_lat(lon, lat)
        return QgsGeometry.fromPointXY(QgsPointXY(lon, lat))

    def create_circle(self, lon, lat, area, segments=90):
        lon, lat = self.normalize_lon_lat(lon, lat)

        radius = self.radius_from_area(area)
        source_point = QgsPointXY(lon, lat)

        utm_crs = QgsCoordinateReferenceSystem(f"EPSG:{self.utm_epsg(lon, lat)}")

        to_utm = QgsCoordinateTransform(
            self.SOURCE_CRS,
            utm_crs,
            self.project
        )
        to_geo = QgsCoordinateTransform(
            utm_crs,
            self.SOURCE_CRS,
            self.project
        )

        point_utm = to_utm.transform(source_point)
        circle = QgsGeometry.fromPointXY(point_utm).buffer(radius, segments)
        circle.transform(to_geo)

        return circle

    def normalize_lon_lat(self, x, y):
        # Normal case for user's table: X=lon, Y=lat.
        if -180 <= x <= 180 and -90 <= y <= 90:
            return float(x), float(y)

        # If coordinates were pasted as lat/lon.
        if -90 <= x <= 90 and -180 <= y <= 180:
            return float(y), float(x)

        return float(x), float(y)

    def transform_geometry_to_layer(self, geometry_4326, layer):
        layer_crs = layer.crs()

        if layer_crs == self.SOURCE_CRS:
            return QgsGeometry(geometry_4326)

        result = QgsGeometry(geometry_4326)

        transform = QgsCoordinateTransform(
            self.SOURCE_CRS,
            layer_crs,
            self.project
        )
        result.transform(transform)

        return result
