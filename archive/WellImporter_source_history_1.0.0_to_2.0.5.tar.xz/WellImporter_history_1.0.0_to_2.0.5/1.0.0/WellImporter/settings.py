# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QSettings


class PluginSettings:
    """Persistent plugin settings."""

    PREFIX = "WellImporter"

    def __init__(self):
        self.settings = QSettings()

    def year(self):
        return int(self.settings.value(f"{self.PREFIX}/year", 2026, type=int))

    def area(self):
        return float(self.settings.value(f"{self.PREFIX}/area", 33.0, type=float))

    def point_layer_name(self):
        return self.settings.value(f"{self.PREFIX}/point_layer_name", "", type=str)

    def polygon_layer_name(self):
        return self.settings.value(f"{self.PREFIX}/polygon_layer_name", "", type=str)

    def save(self, year, area, point_layer_name, polygon_layer_name):
        self.settings.setValue(f"{self.PREFIX}/year", int(year))
        self.settings.setValue(f"{self.PREFIX}/area", float(area))
        self.settings.setValue(f"{self.PREFIX}/point_layer_name", point_layer_name)
        self.settings.setValue(f"{self.PREFIX}/polygon_layer_name", polygon_layer_name)
