# -*- coding: utf-8 -*-

import re
from dataclasses import dataclass

from qgis.PyQt.QtWidgets import QApplication


@dataclass
class WellRecord:
    x: float
    y: float
    number: int


class ClipboardImporter:
    """Reads Excel-like clipboard data: X | Y | Well number."""

    def clipboard_text(self):
        return QApplication.clipboard().text()

    def parse(self):
        text = self.clipboard_text()

        if not text or not text.strip():
            raise Exception("Буфер обмена пуст.")

        records = []
        errors = []

        for row_index, raw_line in enumerate(text.splitlines(), start=1):
            line = raw_line.strip()

            if not line:
                continue

            try:
                record = self._parse_line(line, row_index)
                records.append(record)

            except Exception as exc:
                errors.append(str(exc))

        if errors:
            raise Exception("Ошибки чтения буфера обмена:\n" + "\n".join(errors[:20]))

        return records

    def _parse_line(self, line, row_index):
        parts = self._split_line(line)

        if len(parts) < 3:
            raise Exception(f"Строка {row_index}: нужно минимум 3 столбца: X, Y, Номер скважины.")

        x = self._to_float(parts[0], row_index, "X")
        y = self._to_float(parts[1], row_index, "Y")
        number = self._to_int(parts[2], row_index, "Номер скважины")

        self._check_coordinates(x, y, row_index)

        return WellRecord(x=x, y=y, number=number)

    def _split_line(self, line):
        # Excel normally copies cells separated by tabs. Semicolon is also common.
        if "\t" in line:
            return [p.strip() for p in line.split("\t")]

        if ";" in line:
            return [p.strip() for p in line.split(";")]

        # Comma delimiter is supported only when there are at least two delimiter commas.
        # Decimal comma should not be interpreted as column separator.
        if line.count(",") >= 2 and not re.search(r"\d,\d", line):
            return [p.strip() for p in line.split(",")]

        return re.split(r"\s+", line.strip())

    def _to_float(self, value, row_index, field_name):
        try:
            return float(str(value).strip().replace(",", "."))
        except Exception:
            raise Exception(f"Строка {row_index}: поле {field_name} не является числом.")

    def _to_int(self, value, row_index, field_name):
        try:
            text = str(value).strip()
            if re.match(r"^\d+\.0+$", text):
                text = text.split(".")[0]
            return int(text)
        except Exception:
            raise Exception(f"Строка {row_index}: поле {field_name} должно быть целым числом.")

    def _check_coordinates(self, x, y, row_index):
        if not (-180.0 <= x <= 180.0):
            raise Exception(f"Строка {row_index}: X/долгота вне диапазона -180..180.")

        if not (-90.0 <= y <= 90.0):
            raise Exception(f"Строка {row_index}: Y/широта вне диапазона -90..90.")
