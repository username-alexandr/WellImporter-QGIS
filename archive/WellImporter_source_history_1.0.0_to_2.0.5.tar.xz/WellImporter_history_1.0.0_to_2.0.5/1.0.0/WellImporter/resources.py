# -*- coding: utf-8 -*-
# This plugin loads icon.png directly from the plugin folder.
# If you want compiled Qt resources, run:
# pyrcc5 resources.qrc -o resources.py
